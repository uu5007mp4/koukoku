document.getElementById('custom-button').addEventListener('click', function() {
  alert('カスタムボタンがクリックされました！');
});
